## 🔧 Features
- Real-time monitoring of:
  - ❤️ Heart Rate (MAX30102)
  - 🫁 SpO2 (MAX30102)
  - 💉 Blood Pressure (simulated or from sensor)
- Emergency SMS alert using SIM800L GSM module
- Blynk IoT mobile dashboard for live updates

## 🔌 Hardware Components
| Component        | Description                |
|------------------|----------------------------|
| ESP32 Dev Board  | Main microcontroller       |
| MAX30102         | Heart rate & SpO2 sensor   |
| SIM800L          | GSM module for SMS alerts  |
| MPU6050 (optional)| Motion sensing             |
| Li-ion Battery   | 3.7V 1000mAh power source  |

## 📲 Blynk Dashboard (Virtual Pins)
| Parameter       | Blynk Virtual Pin |
|----------------|-------------------|
| Heart Rate     | V1                |
| SpO2           | V2                |
| Blood Pressure | V3                |
| Alert Status   | V4                |